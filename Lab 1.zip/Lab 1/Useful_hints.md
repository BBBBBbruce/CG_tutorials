# For macOS users: unfortunately, we don't have access to the macOS environment, so we cannot to provide support in environment setup.
# installing opencv: 
1. DICE: already installed
2. Windows WSL/Linux: sudo apt update ; sudo apt install libopencv-dev
3. macOS: maybe try 'brew install opencv'

# compile
mkdir bin
g++ helloworld.cpp -o bin/helloworld
detail can be found in the makefile

# run
./bin/helloworld

# makefile
make life
make run
make clean

# C++ print
#include<iostream>
std::cout<<"print sth";
std::cout<<"print sth\t"; // tab
std::cout<<"print sth\n"; // newline
std::cout<<"print sth"<<std::endl; // newline
if you specify 'using namespace std', then no need for 'std::'






