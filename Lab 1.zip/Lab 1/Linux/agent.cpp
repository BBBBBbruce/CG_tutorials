#include "agent.h"
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */

Agent::Agent()
{
    srand(time(NULL));

    // Implement a random start position, see .h file for directions
    //random a integar from 0 to 63
    position[0] = rand() % 64;
    position[1] = rand() % 64;
}

int* Agent::getPosition()
{
    return this->position;
}

void Agent::setPosition( int x, int y )
{
    this->position[0] = x;
    this->position[1] = y;
}

void Agent::takeRandomAction()
{
    // Implement me, see .h file for directions
    int action = rand() % 4;
    switch (action)
    {
    case 0:
        position[0] += 1;
        break;
    case 1:
        position[0] -= 1;
        break;
    case 2:

        position[1] += 1;
        break;
    case 3:
        position[1] -= 1;
        break;
    default:
        break;
    }
}

void Agent::takePlannedAction()
{
    // Implement me, see .h file for directions
    takeRandomAction();
}

int Agent::getHealth()
{
    return this->health;
}

int Agent::getLoot()
{
    return this->loot;
}

void Agent::eat( )
{
    // Implement me, see .h file for directions
    health+=1;
}

void Agent::mine( )
{
    // Implement me, see .h file for directions
    loot+=1;
}