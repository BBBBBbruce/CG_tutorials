#include <iostream>
using namespace std;

int main ()
{
  cout<<"print sth\t"<<"print sth\n";
  return 0;
}
