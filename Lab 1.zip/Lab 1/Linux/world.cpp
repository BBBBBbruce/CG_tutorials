#include "world.h"
using namespace cv;
using namespace std;

World::World( Agent* a )
{
    this->agent = a;
    srand(time(NULL));
}

void World::createWorld()
{
    // Implement me, see .h file for directions

    //fill member variable world randomly with integer 0,1,2


    int arrayNum[3] = {0,1,2};
    for (auto i =0;i <WORLD_SIZE;i++)
    {
        for (auto j =0;j <WORLD_SIZE;j++)
        {
            this->world[i][j] = arrayNum[rand() % 3];
        }
    }

}

void World::checkAgent( )
{
    assert(this->agent->getPosition()[0] >= 0 && "Position Invalid.");
    assert(this->agent->getPosition()[0] < WORLD_SIZE && "Position Invalid.");
    assert(this->agent->getPosition()[1] >= 0 && "Position Invalid.");
    assert(this->agent->getPosition()[1] < WORLD_SIZE && "Position Invalid.");
}

void World::log(int step)
{
    int image_size = 512;
    Mat img(image_size, image_size, CV_8UC3, Scalar(255,255,255));
    int R, G, B;

    int rect_size = /* IMPLEMENT ME */image_size / WORLD_SIZE;                        

    Scalar color;
    for ( int i = 0; i < WORLD_SIZE; i++ )
    {
        for (int j = 0; j < WORLD_SIZE; j++ )
        {
            int cenx = ( 512 / WORLD_SIZE ) * i + ( 512 / WORLD_SIZE / 2 );
            int ceny = ( 512 / WORLD_SIZE ) * j + ( 512 / WORLD_SIZE / 2 );

            if ( this->agent->getPosition()[0] == i && this->agent->getPosition()[1] == j )
            {
                R = /* IMPLEMENT ME */0;
                G = /* IMPLEMENT ME */0;
                B = /* IMPLEMENT ME */255;
            }
            else
            {
                switch ( this->world[i][j])
                {
                    case FOOD:
                        R = /* IMPLEMENT ME */0;
                        G = /* IMPLEMENT ME */255;
                        B = /* IMPLEMENT ME */0;
                        break;
                    case GOLD:
                        R = /* IMPLEMENT ME */255;
                        G = /* IMPLEMENT ME */255;
                        B = /* IMPLEMENT ME */0;
                        break;
                    default:
                        R = /* IMPLEMENT ME */0;
                        G = /* IMPLEMENT ME */0;
                        B = /* IMPLEMENT ME */0;
                        break;
                }
            }
            const Point pt1(cenx-rect_size,ceny-rect_size), pt2(cenx+rect_size,ceny+rect_size);

            rectangle(img, pt1, pt2, Scalar(B, G, R), -1);
        }
    }
    imwrite( "log_" + std::to_string(step) + ".jpg", img );
}

void World::take_random_step()
{
    // Implement me, see .h file for directions
    // take_random_step tells the agent to take a random step. 
    // The checkAgent function must not be called to verify if the agent is in bounds
    // If valid the resulting position is then checked against the world to see if the agent needs to eat or loot the square. 
    // The required action is then performed, and the value in the world is set to 0 as it no longer contains anything
    // use agent->take_random_step() to get a random step
    cout<<"take random step"<<endl;

    agent->takeRandomAction();

    // print agent position

    //cout<<"position: ("<<this->agent->getPosition()[0]<<","<<this->agent->getPosition()[1]<<")"<<endl;

    while(this->agent->getPosition()[0] < 0|| this->agent->getPosition()[0] >= WORLD_SIZE || this->agent->getPosition()[1] < 0 || this->agent->getPosition()[1] >= WORLD_SIZE)
    {
        agent->takeRandomAction();
    }
    int x1 = this->agent->getPosition()[0];
    int y1 = this->agent->getPosition()[1];

    if (world[x1][y1] == 1)
    {
        agent->eat();
    }
    else if (world[x1][y1] == 2)
    {
        agent->mine();
    }
    this->world[x1][y1] = 0;
}

void World::take_planned_step()
{
    // Implement me, see .h file for directions
    cout<<"take planned step"<<endl;
    agent->takePlannedAction();
    while(this->agent->getPosition()[0] < 0|| this->agent->getPosition()[0] >= WORLD_SIZE || this->agent->getPosition()[1] < 0 || this->agent->getPosition()[1] >= WORLD_SIZE)
    {
        agent->takeRandomAction();
    }
    int x1 = this->agent->getPosition()[0];
    int y1 = this->agent->getPosition()[1];

    if (world[x1][y1] == 1)
    {
        agent->eat();
    }
    else if (world[x1][y1] == 2)
    {
        agent->mine();
    }
    this->world[x1][y1] = 0;
    
}

void World::run(int search_type)
{
    int steps = 0;
    //int max_steps = WORLD_SIZE * WORLD_SIZE;
    int max_steps =100;

    while ( steps < max_steps )
    {
        switch( search_type )
        {
            case RANDOM:
                this->take_random_step();
                break;
            case PLANNED:
                this->take_planned_step();
                break;
            default:
                std::cout << "Invalid choice selected for search type\n";
                exit(-1);
        }

        this->log(steps);
        steps += 1;

        if ( this->agent->getHealth() <= 0 )
        {
            std::cout << "You starved to death!" << std::endl;
            std::cout << "You managed to collect " << this->agent->getLoot() << " loot!" << std::endl;
            return;
        }

    }
}