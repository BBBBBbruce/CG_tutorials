# This is a bash script to run the executable on Linux
# It also works in WSL
# in case of permission deny: try 'chmod u+x Run.sh'

echo "Compiling the program..."
make all            #compile the program
echo "Running the program..."
./TheExecutable     #run the program
echo "Cleaning the directory..."
make clean          #clean the directory

# This might also works on MacOS Since MacOS is based on Unix

# If you are using Windows, you will need to write a batch (*.bat) script.
# If you have gcc in your cmd or powershell, you can use the following command:
# make all            #compile the program
# TheExecutable       #run the program
# make clean          #clean the directory