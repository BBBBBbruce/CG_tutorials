#include "../Headers/triangle.h"
#include <math.h>

Triangle::Triangle( double b, double h )
{
    this->b = b;
    this->h = h;

    this->name = "triangle";
}

double Triangle::Area()
{
    /* IMPLEMENT ME */
}

double Triangle::Perimeter()
{
    /* IMPLEMENT ME */
}
