#include "../Headers/square.h"

Square::Square( double l, double w )
{
    this->l = l;
    this->w = w;
    
    this->name = "square";
}

double Square::Area()
{
    /* IMPLEMENT ME */
}

double Square::Perimeter()
{
    /* IMPLEMENT ME */
}
