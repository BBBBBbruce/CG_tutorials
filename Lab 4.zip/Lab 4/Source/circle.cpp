#include "../Headers/circle.h"

Circle::Circle( double r )
{
    this->r = r;
    this->name = "circle";
}

double Circle::Area()
{
    /* IMPLEMENT ME */
}

double Circle::Perimeter()
{
    /* IMPLEMENT ME */
}

