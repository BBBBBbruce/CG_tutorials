#include "../Headers/shape.h"
#include "../Headers/circle.h"
#include "../Headers/mesh.h"
#include "../Headers/triangle.h"
#include "../Headers/square.h"


using namespace std;

int main () {
    cout<<"\n=====================\n";
    // TODO 0: Finish the implementation of the Shape class and its derived classes
    cout<<"Initialising..."<<endl;
    // TODO 1: Create a vector of Shape; create corresponding objects/classes and add them to the vector
    cout<<"Initialising Finished"<<endl;
    // TODO 2: Iterate through the vector and print the name, area and perimeter of each shape
    cout<<"Running MainLoop..."<<endl;
    // An example template: for(auto i = 0; i < ShapeVec.size(); i++) {}
    cout<<"MainLoop Finished"<<endl;
    cout<<"Free Memory"<<endl;
    // TODO 3: destroy the vector and the objects it contains

    cout<<"Program Finished"<<endl;
    cout<<"===================== \n ";
    return 0;
}
