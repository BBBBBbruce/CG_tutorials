#include "../Headers/mesh.h"
#include "../Headers/shape.h"
#include <math.h>
#include <fstream>
#include <vector> 
#include <sstream> 

using namespace std;

Mesh::Mesh( string filename )
{
    ifstream plyfile(filename.c_str());
    string line;

    if (plyfile.is_open())
    {
        int tri_count, vert_count;
        string s; 
        const char delim = ' ';
        vector<Point> pts;
        while ( getline(plyfile, line) )
        {
            if ( line.compare("end_header") == 0 )
            {
                break;
            }
 
            stringstream ss(line); 
            while ( getline(ss, s, delim) )
            {
                if ( s.compare("vertex") == 0 )
                {
                    getline(ss, s, delim);
                    vert_count = stoi( s );
                }

                if ( s.compare("face") == 0 )
                {
                    getline(ss, s, delim);
                    tri_count = stoi( s );
                }
            }
        }
        cout<<vert_count<<"/"<<tri_count<<endl;
        for ( int i = 0; i < vert_count; i++ )
        {
            getline(plyfile, line);
            stringstream ss(line); 
            getline(ss, s, delim);
            double a = stod( s );
            getline(ss, s, delim);
            double b = stod( s );
            getline(ss, s, delim);
            double c = stod( s );
            pts.push_back( Point(a, b, c) );
        }

        for ( int i = 0; i < tri_count; i++ )
        {
            getline(plyfile, line);
            stringstream ss(line); 
            getline(ss, s, delim); //Burn the number of points
            getline(ss, s, delim);
            int d = stod( s );
            getline(ss, s, delim);
            int e = stod( s );
            getline(ss, s, delim);
            int f = stod( s );

            this->tris.push_back( Face( pts.at(d), pts.at(e), pts.at(f) ) );
        }

        plyfile.close();
    }
    this->name = "mesh";
}

double Mesh::Area()
{
    /* IMPLEMENT ME */
}

double Mesh::Perimeter()
{
    /* IMPLEMENT ME */
}
