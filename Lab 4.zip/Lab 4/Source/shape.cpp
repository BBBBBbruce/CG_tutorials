#include "../Headers/shape.h"

void Shape::to_string()
{
    cout << "This object is a " << this->getName() << " the area is " << this->Area() << " and the perimeter is " << this->Perimeter() << endl;
}

string Shape::getName()
{
    return this->name;
}
