#ifndef SQUARE_H
#define SQUARE_H

#include "shape.h"

class Square : public Shape {
    public:
        Square( double l, double w );
        double Area();
        double Perimeter();

    private:
        double l, w;
};

#endif
