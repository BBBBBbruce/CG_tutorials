#ifndef SHAPE_H
#define SHAPE_H

using namespace std; 
#include <iostream>
#include <string>

struct Point {
    double x, y, z;
    Point( double x, double y, double z ) : x(x), y(y), z(z){}
    Point(){}
};
 
struct Face {
    Point a, b, c;	
    Face (Point a, Point b, Point c) : a(a), b(b), c(c) {}
};

class Shape {
  public:
    virtual double Area() = 0;
    virtual double Perimeter() = 0;
    void to_string();
    string getName();
    static constexpr double PI = 3.14159265359;
    string name;
};

#endif
