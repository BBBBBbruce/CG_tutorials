#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "shape.h"

class Triangle : public Shape {
    public:
        Triangle( double b, double h );
        double Area();
        double Perimeter();

    private:
        double b, h;
};

#endif
