#ifndef MESH_H
#define MESH_H

#include "shape.h"
#include <string>
#include <vector>

using namespace std;

class Mesh : public Shape {
    public:
        Mesh( string filename );
        double Area();
        double Perimeter();

    private:
        vector<Face> tris;
};

#endif
